#include "main.h"
#include <cstdio>
void odump(path const &out, path const &in);
pair<unsigned char *, unsigned int> readofile(path const &p){
  pair<unsigned char*,unsigned int> r={nullptr,0};
  FILE*f=fopen(p.c_str(),"rb"); if(!f) return r; fseek(f,0,SEEK_END); unsigned n=ftell(f); fseek(f,0,SEEK_SET);
  r.first=new unsigned char[n+4096]; memset(r.first,0,n+4096); fread(r.first,1,n,f); r.second=n; fclose(f); return r;}
int main(int c,char**v){ odump(v[2],v[1]); return 0; }
#include <algorithm>
char *FormattingUtils::GetBuf(){ static char b[65536]; return b; }
void FormattingUtils::WindowsMessageBoxA(char const*m,char const*t,unsigned i){ fprintf(stderr,"%s: %s\n",t,m); }
string ToLower(string const&s){ string r=s; for(auto&c:r) c=tolower(c); return r; }
GlobalOptions &options(){ static GlobalOptions o; return o; }
